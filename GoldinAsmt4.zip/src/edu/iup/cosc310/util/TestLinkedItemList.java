package edu.iup.cosc310.util;
/**
 * Tests LinkedItemList.
 * @author JoshuaGoldin
 *
 */
//import java.util.Iterator;

public class TestLinkedItemList {
	public static void main(String[] args) {
		ItemList<Double> list = new LinkedItemList<Double>();

		// Test list
		assert list.getNoItems() == 0 : "Expect getNoItems() to be , got " + list.getNoItems();
		try {
			list.getItem(-1);
			System.out.println(list.getItem(-1));
			assert false : "getItem(-1) did not throw IllegalArgumentException";
		} catch (IllegalArgumentException e) {
		} catch (Exception e) {
			assert false: "getItem(-1) did not throw IllegalArgumentException, instead threw "
					+ e.getClass().getSimpleName();
		}
		try {
			list.getItem(0);
			assert false : "getItem(0) did not throw IllegalArgumentException";
		} catch (IllegalArgumentException e) {
		} catch (Exception e) {
			assert false : "getItem(0) did not throw IllegalArgumentException, instead threw "
					+ e.getClass().getSimpleName();
		}
		
		// Test list
		list.addItem(0.0);
		list.addItem(1.0);
		list.addItem(2.0);

		assert list.getNoItems() == 3.0 : "Expect getNoItems() to be 3, got " + list.getNoItems();


		assert list.getItem(0) == 0.0 : "Expect getItem() to be 0.0 , got " + list.getItem(0);;

		try {
			list.getItem(4);
			assert false : "getItem(4) did not throw IllegalArgumentException";
		} catch (IllegalArgumentException e) {
		} catch (Exception e) {
			assert false : "getItem(1) did not throw IllegalArgumentException, instead threw "
					+ e.getClass().getSimpleName();
		}

		// Test list
		list.addItem(3.0);
		list.addItem(4.0);

		assert list.getNoItems() == 5 : "Expect getNoItems() to be 5, got " + list.getNoItems();


		assert list.getItem(0) == 0.0 : "Expect getNoItems() to be 0.0, got " + list.getNoItems();;
		assert list.getItem(1) == 1.0 : "Expect getNoItems() to be 1.0, got " + list.getNoItems();
		assert list.getItem(2) == 2.0 : "Expect getNoItems() to be 2.0, got " + list.getNoItems();;

		try {
			list.getItem(5);
			assert false : "getItem(3) did not throw IllegalArgumentException";
		} catch (IllegalArgumentException e) {
		} catch (Exception e) {
			assert false : "getItem(3) did not throw IllegalArgumentException, instead threw "
					+ e.getClass().getSimpleName();
		}

		// Test list
		list.insertItem(-1.0, 0);

		assert list.getNoItems() == 6;

		try {
			list.getItem(-1);
			assert false : "getItem(-1) did not throw IllegalArgumentException";
		} catch (IllegalArgumentException e) {
		} catch (Exception e) {
			assert false : "getItem(-1) did not throw IllegalArgumentException, instead threw "
					+ e.getClass().getSimpleName();
		}


		// Test list
		double j = list.removeItem(0);

		assert j == -1.0 : "Removed item should be -1.0 , got " + j;

		assert list.getNoItems() == 5;

		assert list.getItem(0) == 0.0 : "Expect getItem() to be 0.0 , got " + list.getItem(0);;
		assert list.getItem(1) == 1.0 : "Expect getItem() to be 1.0 , got " + list.getItem(1);;
		assert list.getItem(2) == 2.0 : "Expect getItem() to be 2.0 , got " + list.getItem(2);;

		try {
			list.getItem(5);
			assert false : "getItem(3) did not throw IllegalArgumentException";
		} catch (IllegalArgumentException e) {
		} catch (Exception e) {
			assert false : "getItem(3) did not throw IllegalArgumentException, instead threw "
					+ e.getClass().getSimpleName();
		}

		// Test list
		list.insertItem(1.5, 2);

		assert list.getNoItems() == 6;


		// Test list
		j = list.removeItem(1);

		assert j == 1.0 : "Removed item should be 1.0, got " + j;

		assert list.getNoItems() == 5;


		// Test list
		list.insertItem(4.1, 5);

		assert list.getNoItems() == 6;

		assert list.getItem(5) == 4.1 : "getItem(5) is expected to get 4.1 , " + list.getItem(5);

		try {
			list.getItem(6);
			assert false : "getItem(4) did not throw IllegalArgumentException";
		} catch (IllegalArgumentException e) {
		} catch (Exception e) {
			assert false : "getItem(4) did not throw IllegalArgumentException, instead threw "
					+ e.getClass().getSimpleName();
		}

		// Test list
		j = list.removeItem(3);

		assert j == 3.0 : "Removed item should be 3.0, got " + j;

		assert list.getNoItems() == 5;


		assert list.getItem(0) == 0.0;
		assert list.getItem(1) == 1.5;
		assert list.getItem(2) == 2.0;


		// Test list
		try {
			list.insertItem(0.0, -1);
			assert false : "insertItem(0.0, -1) did not throw IllegalArgumentException";
		} catch (IllegalArgumentException e) {
		} catch (Exception e) {
			assert false : "insertItem(0.0, -1) did not throw IllegalArgumentException, instead threw "
					+ e.getClass().getSimpleName();
		}


		assert false : "Test complete - no errors";
	}
}

package edu.iup.cosc310.util;

/**
 * Tests LinkedItemList.
 * @author JoshuaGoldin
 *
 */

import java.util.ListIterator;
public class IteratorTest {
	public static void main(String[] args) {
		// Linked Item List
		LinkedItemList<Double> list = new LinkedItemList<Double>();

		list.addItem(0.0);
		list.addItem(1.0);
		list.addItem(2.0);

		ListIterator<Double> iList = list.listIterator();
		
		assert iList.hasNext();
		assert iList.next() == 0.0;
		assert iList.hasNext();
		assert iList.next() == 1.0;
		assert iList.hasNext();
		assert iList.next() == 2.0;
		assert !iList.hasNext();
		
		
		
		iList = list.listIterator();
		
		// Test hasNext, next, hasPrevious, and previous
		assert iList.hasNext();
		assert iList.next() == 0.0;
		assert iList.hasNext();
		assert iList.next() == 1.0;
		assert iList.hasNext();
		assert iList.next() == 2.0;
		assert !iList.hasNext();
		assert iList.hasPrevious();
		assert iList.previous() == 2.0;
		assert iList.hasPrevious();
		assert iList.previous() == 1.0;
		assert iList.hasPrevious();
		assert iList.previous() == 0.0;
		assert !iList.hasPrevious();

		iList.add(3.0);

		iList.next();
		assert iList.nextIndex() == 1.0 : "Expected 1.0 got, " + iList.nextIndex();
		iList.next();
		assert iList.next() == 2.0 : "Expected 2.0 got, " + iList.next();
		iList.next();
		assert iList.previousIndex() == 0.0 : "Expected 0.0 got, " + iList.previousIndex();

		// Test remove
		iList.remove();
		//iList.next();
		assert iList.previous() == 2.0 : "Expected 2.0 got, " + iList.previous();

		// Test Set
		iList.next();
		iList.set(4.0);
		iList.previous();
		assert iList.next() == 4.0;
		assert false : "Test complete - no errors";
		System.out.println("Assertions not enabled, re-run with vm arguments -ea");
	}
}

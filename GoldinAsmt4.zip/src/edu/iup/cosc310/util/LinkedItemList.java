package edu.iup.cosc310.util;

/**
 * Tests LinkedItemList.
 * @author JoshuaGoldin
 *
 */

import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;



public class LinkedItemList<E> implements ItemList<E>{
	private int noItems;
	private Node dummy;
	
	public Iterator<E> iterator() {
		return new It();
	}
	public ListIterator<E> listIterator() {
		return new It();
	}
	private class Node {
		E data;
		Node next;
		Node prev;
		public Node(LinkedItemList<E>.Node prev, E data, LinkedItemList<E>.Node next) {
			super();
			this.prev=prev;
			this.data=data;
			this.next=next;
		}
	}
	
	private class It implements ListIterator<E> {
		private Node current = dummy.next;
		private Node last=null;
		private int index=0;
		
		@Override
		public boolean hasNext() {
			return current != dummy;
		}
		
		@Override
		public E next() {
			if (!hasNext()) {
				throw new NoSuchElementException();
			}
			last=current;
			E data=current.data;
			current=current.next;
			index++;
			return data;
		}
		@Override
		public boolean hasPrevious() {
			return index>0;
		}
		@Override
		public E previous() {
			if (!hasPrevious()) {
				throw new NoSuchElementException(); 
			}
			last = current;
			//E data=current.data;
			current = current.prev;
			index--;
			return current.data;
		}
		@Override
		public int nextIndex() {
			if (hasNext()) {
				return index;
			}
			else {
				throw new NoSuchElementException();
			}
		}
		@Override
		public int previousIndex() {
			if (hasPrevious()) {
				return 0;
			}
			else {
				throw new NoSuchElementException();
			}
		}
		@Override
		public void remove() {
			if ( last == null) {
				throw new IllegalStateException();
			}
			removeNode(last);
			last=null;
		}
		@Override
		public void set(E data) {
			if (last == null) throw new IllegalStateException(); {
				last.data=data;
			}
			
		}
		@Override
		public void add(E data) {
			insertBefore(data, dummy);
			
		}

	}
	public void addItem( E data) {
		insertBefore(data, dummy);
	}
	/**
	 * Get length of list.
	 * @return noItems
	 */
	@Override
	public int getNoItems() {
		return noItems;
	}
	public E getItem(int index) {
		return getNode(index).data;
	}
	/**
	 * Get node pointer.
	 * @param index
	 * @return ptr
	 */
	private Node getNode(int index) {
		if (index <0 || index >= noItems) {
			throw new IllegalArgumentException("Invalid index " + index);
		}
		Node ptr = dummy.next;
		while (index-- > 0) {
			ptr = ptr.next;
		}
		return ptr;
	}
	public void insertBefore(E data, Node node) {
		node.prev = node.prev.next = new Node(node.prev, data, node);
		noItems++;
	}
	/**
	 * Insert item at specified location.
	 * @param item
	 * @param index
	 */
	@Override
	public void insertItem(E item, int index) {
		Node ptr;
		if (index == noItems) {
			ptr=dummy;
		} else {
			ptr = getNode(index);
		}
		insertBefore(item, ptr);
	}
	/**
	 * 
	 * @param node
	 * @return node.data
	 */
	private E removeNode(Node node) {
		node.prev.next=node.next;
		node.next.prev=node.prev;
		noItems--;
		return node.data;
	}
	
	/**
	 * Remove item.
	 * @param index
	 * @return removed data
	 */
	@Override
	public E removeItem(int index) {
		return removeNode(getNode(index));
	}
	
	public LinkedItemList() {
		dummy = new Node(null, null, null);
		dummy.next=dummy.prev=dummy;
	}
	
}

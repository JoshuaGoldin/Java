package edu.iup.cosc310.bo;

/**
 * A Department of a Company.
 * 
 * @author Joshua Goldin
 * 
 */

import java.util.Iterator;
import edu.iup.cosc310.util.*;

public class Department implements Iterable<Employee>{
	private String deptCode;
	private String deptName;
	private String mgrEmpId;
	private ItemList<Employee> employees=new LinkedItemList<Employee>();
	private Employee manager;
	
	/**
	 * Department constructor.
	 * 
	 * @param deptCode
	 * 
	 * @param deptName
	 * 
	 * @param mgrEmpId
	 * 
	 */
	
	public Department(String deptCode, String deptName, String mgrEmpId) {
		this.deptCode=deptCode;
		this.deptName=deptName;
		this.mgrEmpId=mgrEmpId;
	}
	
	/**
	 * Add employee to department list.
	 * 
	 * @param employee
	 * 
	 */
	public void addEmployee(Employee employee) {
		employees.addItem(employee);
	}
	
	/**
	 * Get department code.
	 * 
	 * @return deptCode
	 */
	public String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * Get department name.
	 * 
	 * @return deptName
	 */

	public String getDeptName() {
		return deptName;
	}
	/**
	 * Get department manager.
	 * 
	 * @return manager.
	 */
	public Employee getManager() {
		if (manager == null) {
			for (Iterator<Employee> it =employees.iterator(); it.hasNext();) {
				Employee emp = it.next();
				if (emp.getEmployeeId().equals(mgrEmpId)) {
					manager = emp;
					break;
				}
			}
		}
		return manager;
	}
	/**
	 * Get employee number.
	 * 
	 * @return employee.getNoItems()
	 */
	public int getNoEmployees() {
		return employees.getNoItems();
	}
	/**
	 * Get employee.
	 * 
	 * @param index
	 * @return employees.getItem(index)
	 * @throws IndexOutOfBoundsException
	 *             
	 */
	public Employee getEmployee(int index) {
		return employees.getItem(index);
	}
	/**
	 * Get total vacation days.
	 * 
	 * @return totalVacationDays
	 */
	public int getTotalVacationDays() {
		int totalVacationDays = 0;
		for (Iterator<Employee> it = employees.iterator(); it.hasNext();) {
			Employee emp = it.next();
			totalVacationDays += emp.getVacationDays();
		}
		return totalVacationDays;
	}

	@Override
	public Iterator<Employee> iterator() {
		return employees.iterator();
	}
}

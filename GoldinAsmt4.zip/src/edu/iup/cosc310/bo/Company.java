package edu.iup.cosc310.bo;

/**
 * A Company.  Maintains a list of departments and methods access
 * the company's departments.
 * 
 * @author Joshua Goldin
 */

import java.util.*;

import edu.iup.cosc310.util.ItemList;
import edu.iup.cosc310.util.LinkedItemList;

public class Company implements Iterable <Department>{
	private ItemList<Department> departments=new LinkedItemList<Department>();
	/**
	 * Add department.
	 * 
	 * @param department
	 */
	public void addDepartment(Department department) {
		departments.addItem(department);
	}
	/**
	 * Find department.
	 * 
	 * @param deptCode
	 * @return department or null
	 */
	public Department findDepartment(String deptCode) {
		for (Iterator<Department> dep = departments.iterator(); dep.hasNext();) {
			Department department = dep.next();
			if (deptCode.equals(department.getDeptCode())) {
				return department;
			}
		}
		return null;
	}
	/**
	 * Get noDepartment.
	 * @return departments.getItem(i)
	 */
	public Department getDepartment(int i) {
		return departments.getItem(i);
	}
	/**
	 * Get Nodepartments.
	 * @param i
	 * @return departments.getNoItems(i)
	 */
	public int getNoDepartments() {
		return departments.getNoItems();
	}
	@Override
	public Iterator<Department> iterator() {
		return departments.iterator();
	}
}

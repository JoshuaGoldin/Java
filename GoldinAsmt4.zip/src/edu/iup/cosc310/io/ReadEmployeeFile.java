package edu.iup.cosc310.io;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import edu.iup.cosc310.bo.Department;
import edu.iup.cosc310.bo.Employee;


/**
 * Helper class to read employees from a binary employee file.  
 * The method readEmployee() returns the next employee from 
 * the employee file.
 * 
 * @author Joshua Goldin
 */

public class ReadEmployeeFile {
	private DataInputStream input;
	
	/**
	 * Constructor - opens the employee file.
	 * @param fileName - name of the employee file
	 * @throws FileNotFoundException - in the event the file could not be opened
	 */
	
	public ReadEmployeeFile(String fileName) throws FileNotFoundException {
		input = new DataInputStream(new FileInputStream(fileName));
	}
	
	/**
	 * Read the next employee from the employee file.
	 * @return an employee.  Returns null in the event the end of
	 * the employee file is reached.
	 * @throws IOException
	 */
	
	@SuppressWarnings("deprecation")
	public Employee readEmployee() throws IOException {
		if (input.available() == 0) {
			return null;
		}
		byte[] employeeIdByte = new byte[3];
		byte[] lastNameBytes = new byte[15];
		byte[] firstNameBytes = new byte[20];
		
		input.read(employeeIdByte);
		String employeeId = new String (employeeIdByte);
		String empIndicator = "" + (char) input.readByte();
		String deptCode = "" + (char) input.readByte();
		input.read(lastNameBytes);
		String lastName = new String(lastNameBytes).trim();
		input.read(firstNameBytes);
		String firstName = new String(firstNameBytes).trim();
		float salary = input.readFloat();
		byte month = input.readByte();
		byte day = input.readByte();
		short year = input.readShort();
		Date hireDate = new Date(year - 1900, month -1, day);
		short vacationDays = input.readShort();
		byte training = input.readByte();
		
		Employee employee = new Employee(employeeId, empIndicator, deptCode, firstName,
				lastName, salary, hireDate, vacationDays, training);
		return employee;
	}
	
	/**
	 * Close the employee file
	 * @throws IOException
	 */
	
	public void close() throws IOException {
		input.close();
	}
	
	public static void main(String[] args) throws IOException {
		ReadEmployeeFile in=new ReadEmployeeFile(args[0]);
		SimpleDateFormat dateFormatter = new SimpleDateFormat("MM//dd//yyyy");

		Employee emp;
		int no = 0;
		while ((emp=in.readEmployee()) != null) {
			if (no==(42) || no==(142)) {
			System.out.printf("%d %-5s %-20s %-12s $%6.2f %6d %s %s %x\n", no,
					emp.getEmployeeId(), emp.getFirstName() + " "+ emp.getLastName(),
					dateFormatter.format(emp.getHireDate()), emp.getSalary(),
					emp.getVacationDays(), emp.getEmployeeIndicator(), emp.getDeptCode(), emp.getTraining());
			}
			no++;

		}

	}
	
}
